package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        // السطرين دول عشان أي رسائل
        System.setProperty("webdriver.chrome.silentOutput", "true");
        Logger.getLogger("org.openqa.selenium").setLevel(Level.OFF);

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        WebDriver driver = new ChromeDriver(options);

        try {
            driver.get("http://127.0.0.1:5500/files/index.html");
            driver.manage().window().maximize();

            // السيستم شغال
            System.out.println("[INFO] System Started: Navigating to Flora Website...");
            Thread.sleep(2000);

            WebElement signUpBtn = driver.findElement(By.xpath("//*[contains(text(),'Sign Up')]"));
            signUpBtn.click();
            System.out.println("[INFO] Action: Newsletter Dialog Opened.");

            Thread.sleep(1500);

            List<WebElement> inputs = driver.findElements(By.tagName("input"));

            if (inputs.size() >= 3) {
                // هنا إحنا بنعمل إيه بالظبط
                System.out.println("[PROC] Entering User Credentials...");
                typeLikeHuman(inputs.get(1), "shahd alaa");
                Thread.sleep(1000);
                typeLikeHuman(inputs.get(2), "shahd@test.com");

                System.out.println("[PROC] Submitting Form...");
                Thread.sleep(1500);
                inputs.get(2).submit();
            }

            Thread.sleep(2000);
            if (driver.getPageSource().contains("Success")) {
                System.out.println("\n************************************");
                System.out.println("   AUTOMATION TEST STATUS: PASSED    ");
                System.out.println("   Timestamp: " + new java.util.Date());
                System.out.println("************************************\n");
            }

        } catch (Exception e) {
            System.out.println("[ERROR] Test interrupted: " + e.getMessage());
        }
    }

    public static void typeLikeHuman(WebElement element, String text) throws InterruptedException {
        element.clear();
        for (char c : text.toCharArray()) {
            element.sendKeys(String.valueOf(c));
            Thread.sleep(150);
        }
    }
}